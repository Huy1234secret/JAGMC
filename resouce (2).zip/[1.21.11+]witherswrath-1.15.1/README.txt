  ________  __  __    __                        
 |  |  |  ||__||  |_ |  |--..-----..----..-----.
 |  |  |  ||  ||   _||     ||  -__||   _||__ --|
 |________||__||____||__|__||_____||__|  |_____|
                                                
   ________               __    __    
  |  |  |  |.----..---.-.|  |_ |  |--.
  |  |  |  ||   _||  _  ||   _||     |
  |________||__|  |___._||____||__|__| V1.15
                                      

Heyo!

If you're reading this it means you're either trying to edit something or inspecting the datapack.

If you're looking to change the default settings of this datapack please go to data/wither/function/initialize_Storage and open with a text editing app.
!!! DO NOT change the initialized option as this is what the datapack uses to add the default values.
All the different toggles will have the prefix "toggle" before the different options


PS. if you're planning to use this on a singleplayer or a server you don't need to change any files and can just do /function wither:config to change
the values and it will save the values per world.

Alternatively Check out where you downloaded this pack as there is now a Bedrock Default option and a Wither's Wrath
  - The Bedrock version includes:
    Bedrock Parity making it as close as possible without any of the extra stuff.